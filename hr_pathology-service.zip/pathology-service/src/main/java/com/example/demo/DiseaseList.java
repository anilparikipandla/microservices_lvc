package com.example.demo;

import java.util.List;

public class DiseaseList {

	public DiseaseList() {
		// TODO Auto-generated constructor stub
	}
	
	private List<Disease> diseases;
	
	public List<Disease> getDiseases(){
		return diseases;
	}

	public void setDiseases(List<Disease> diseases) {
		this.diseases = diseases;		
	}
	
	
	

}
